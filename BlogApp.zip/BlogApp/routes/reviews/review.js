const express = require('express');
const router = express.Router();
const Article = require('../../models/articles');
const Review = require('../../models/review');
// const { isLoggedIn } = require('../../middleware');



router.post('/articles/:id/review',/*isLoggedIn*/async(req, res) => {

    // console.log(req.body.review);
    // res.send("worked");

    const articles = await Article.findById(req.params.id);

    const { rating, body } = req.body.review;

    const { username } = req.user; 

    let review = new Review({rating:rating,body:body,username:username});

    articles.reviews.push(review);

    await review.save();
    await articles.save();

    res.redirect(`/articles/${req.params.id}`);
});


module.exports = router;
