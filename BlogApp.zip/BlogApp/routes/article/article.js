const express = require('express');
const router = express.Router();
const Article = require('../../models/articles');





router.get("/" , (req,res)=> {

    res.render('articles/HomePage');
}) 

//get all the products
router.get('/articles', async(req, res) => {
    const articles = await Article.find({});
    res.render('articles/index', { articles: articles });
})

//creating object of article
router.get('/articles/new', (req, res) => {
    res.render('articles/new');
})

//display new article on /articles
router.post('/articles',async(req, res) => {
    
    await Article.create(req.body.Article);

    res.redirect('/articles');
})


// display a particular article y clicking on Read more
router.get('/articles/:id', async(req, res) => {
    
    const articles =  await Article.findById(req.params.id).populate('reviews');

    res.render('articles/readmore', { articles: articles });
})


router.get('/articles/:id/edit', async(req, res) => {
    
    const articles = await Article.findById(req.params.id);

    res.render('articles/edit', { articles: articles });
})

router.patch('/articles/:id', async(req, res) => {
    
    const articles = await Article.findByIdAndUpdate(req.params.id, req.body.Article);

    res.redirect(`/articles/${req.params.id}`);
})



router.delete('/articles/:id', async(req, res) => {
    
    await Article.findByIdAndDelete(req.params.id);

    res.redirect('/articles');
})

module.exports = router;