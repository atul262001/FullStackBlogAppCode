const mongoose = require('mongoose');
const Review = require('./review');

const ArticleSchema = new mongoose.Schema({
    img : {
        type : String,
        required : true
    },
    title : {
        type : String,
        required : true
    },
    createdBy : {
       type : String,
       required : true
    },
    createdAt : {
        type : Date,
        default :  new Date()
    },
    desc : {
        type : String,
        minLength : 10,
        required : true

    },
    reviews : [
        {
            type: mongoose.Schema.Types.ObjectId,
            ref:'Review'
        }  
    ]
})

const Article = mongoose.model('Article',ArticleSchema);

module.exports = Article;