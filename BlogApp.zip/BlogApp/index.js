const express = require('express');
const app = express();
const mongoose = require('mongoose');
const path = require('path');
const methodOverride = require('method-override')
const Article = require('./models/articles');
const seedDB = require('./seedDB');
const articleRoutes = require('./routes/article/article');
const reviewRoutes = require('./routes/reviews/review');
const session = require('express-session');
const passport = require('passport');
const LocalStrategy = require('passport-local');
const User = require('./models/user.js');
const authRoutes = require('./routes/auth/auth');


mongoose.connect('mongodb://localhost/app', 
      {useNewUrlParser: true, 
          useUnifiedTopology: true,
          useFindAndModify: false,
        useCreateIndex:true
       })

     .then(()=>{
    console.log("connection open success");
})
.catch( err => {
    console.log("db not connected");
    console.log(err);
}) 



app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '/views'));
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.use(methodOverride('_method'))
mongoose.set('useFindAndModify',false);


app.use(session({
    secret: 'thisisnotagoodsecret',
    resave: false,
    saveUninitialized: true
}))


app.use(passport.initialize());
app.use(passport.session());


passport.use(new LocalStrategy(User.authenticate()));

passport.serializeUser(User.serializeUser());
passport.deserializeUser(User.deserializeUser());

//seedDB();

app.get("/" , (req,res)=> {

    res.render('articles/HomePage');
}) 

// app.get("/articles" , (req,res)=> {

//     res.render('articles/index');
// }) 
// app.get('/articles', async(req, res) => {
//     const articles = await Article.find({});
//     res.render('articles/index', { articles: articles });
// })

// app.get("/articles", (req,res)=> {
//     const articles = [{
//         title : 'type Article title',
//         createdAt : Date.now(),
//         description : 'type desc here'
//     },
//     {
        
//             title : 'type Article title',
//             createdAt : Date.now(),
//             description : 'type desc here'
        
//     }]
//     res .render('index', { articles: articles})
// })

// //const articleRouter = require('./routes/articles');
app.use(articleRoutes);
app.use(reviewRoutes);
app.use(authRoutes);


app.listen(3000, ()=>{
    console.log("Server Started");
}) 
