const mongoose = require('mongoose');
const Article = require('./models/articles');

const arr = [
    {   
        img : "https://images.unsplash.com/photo-1491975474562-1f4e30bc9468?ixid=MXwxMjA3fDB8MHxzZWFyY2h8MTl8fHN0dWR5JTIwaGFja3N8ZW58MHx8MHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60",
        title : 'Study Hacks',
        createdBy : 'Manan Sharma',
        desc : "I am actually a consistent reader of Cal Newport’s blog (known as StudyHacks), although recently he has moved on to “career hacks” in that he addresses career and job advice over studying in college.One thing I love about Cal’s blog is that is isn’t afraid to speak out against the status quo, yet only does so when he has data and a strong argument to present He doesn’t stir up controversy just to do so, yet many of his posts are controversial because he cites evidence that goes against a lot of beliefs that we often hold. (For instance, he doesn’t believe in “Following your passion”, that definitely threw me for a loop!)"
        
        
    },
    {   
        img : "https://images.unsplash.com/photo-1499781350541-7783f6c6a0c8?ixid=MXwxMjA3fDB8MHxzZWFyY2h8MXx8YXJ0fGVufDB8fDB8&ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60 ",
        title : 'Supersonic Art',
        createdBy : 'Gourav Kapoor',
        desc : "Another blog I randomly check from time to time, the art featured here can be pretty amazing (Warning: it is sometimes Not Safe For Work). As an art blog, this site initially made it’s name with top quality selections and acted as a great promotion method for new artists.Later, with an established name, people now submit their art in hopes of being featured.I found this to be the exact case with my electronic music blog, as when I grew in popularity, people messaged ME about getting featured, rather than the other way around."
    },
    {   
        img : "https://images.unsplash.com/photo-1549590143-d5855148a9d5?ixid=MXwxMjA3fDB8MHxzZWFyY2h8OXx8Y29va2luZ3xlbnwwfHwwfA%3D%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60 ",
        title : 'Smitten Kitchen',
        createdBy : 'Ritesh Chopra',
        desc : "Smitten Kitchen is one of those blogs that might have actually greatly benefitted from Pinterest (whereas most don’t), because not only does Deb throw down some delicious recipes, her personal photos are well done and made to be shared.This blog has gotten a lot of press, and one main thing the authors tout is their tiny kitchen.This selling point related to a lot of folks: you can make great meals even in a small kitchen.It made this blog more “real” than those cooking shows with giant kitchens and pre-chopped ingredients."
    },
    {
        img : "https://images.unsplash.com/photo-1449450664975-6fed86611267?ixid=MXwxMjA3fDB8MHxzZWFyY2h8M3x8cGhvdG9ncmFwaHklMjBtb3VudGFpbnN8ZW58MHx8MHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60 ",
        title : 'Canvas of Light',
        createdBy : 'Kashish Chugh',
        desc : "Photo travel blogs are a dime a dozen, and Canvas of Light made the cut here because the photos are amazing.Nothing much I can add here, other than the author goes all out and has a lot of talent.Great example of taking an excellent skill and making a truly memorable blog out of it.Honestly, few people are going to care about your random movie reviews on something that came out 10 years (or even 10 minutes) ago."
    },
]
function seedDB() {
    
    Article.insertMany(arr)
        .then(() => {
            console.log("Data Seeded");
    })
    .catch(err => {
            console.log(err);
    })

}

module.exports = seedDB;